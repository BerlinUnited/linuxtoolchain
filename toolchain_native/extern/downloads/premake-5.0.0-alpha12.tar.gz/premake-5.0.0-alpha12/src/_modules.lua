--
-- _modules.lua
-- The list of core modules to preload on startup
-- Copyright (c) 2015 Jason Perkins and the Premake project
--

	return {
		"gmake",
		"vstudio",
		"xcode",
		"codelite",
		"gmake2",
		"d",
	}
