return {
	"_preload.lua",
	"codelite.lua",
	"codelite_workspace.lua",
	"codelite_project.lua",
}
