Premake extension to support the [CodeLite](http://www.codelite.org/) IDE

### Features ###

* Support for C/C++ language projects

### Usage ###

Simply generate your project using the `codelite` action:
```bash
premake5 codelite
```
and open the generated project file in CodeLite.
