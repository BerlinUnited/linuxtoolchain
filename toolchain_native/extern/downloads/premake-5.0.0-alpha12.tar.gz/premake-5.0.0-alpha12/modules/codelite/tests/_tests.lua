require ("codelite")

return {
	"test_codelite_workspace.lua",
	"test_codelite_project.lua",
	"test_codelite_config.lua",
}
