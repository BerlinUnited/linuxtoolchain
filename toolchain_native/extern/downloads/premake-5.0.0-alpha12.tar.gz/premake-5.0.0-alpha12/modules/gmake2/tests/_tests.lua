require ("gmake2")

return {
	"test_gmake2_clang.lua",
	"test_gmake2_file_rules.lua",
	"test_gmake2_flags.lua",
	"test_gmake2_ldflags.lua",
	"test_gmake2_linking.lua",
	"test_gmake2_objects.lua",
	"test_gmake2_pch.lua",
	"test_gmake2_target_rules.lua",
	"test_gmake2_tools.lua",
}
