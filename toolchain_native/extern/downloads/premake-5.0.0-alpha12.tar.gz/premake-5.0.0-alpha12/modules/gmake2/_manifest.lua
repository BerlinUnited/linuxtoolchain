return {
	"_preload.lua",
	"gmake2.lua",
	"gmake2_cpp.lua",
	"gmake2_csharp.lua",
	"gmake2_makefile.lua",
	"gmake2_utility.lua",
	"gmake2_workspace.lua",
}
