return {
	"_preload.lua",
	"d.lua",
	"actions/gmake.lua",
	"actions/vstudio.lua",
	"tools/dmd.lua",
	"tools/gdc.lua",
	"tools/ldc.lua",
}
