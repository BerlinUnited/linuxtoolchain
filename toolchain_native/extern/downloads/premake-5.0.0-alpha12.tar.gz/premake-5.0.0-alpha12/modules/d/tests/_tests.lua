require ("d")

return {
	"test_visualstudio.lua",
	"test_gmake.lua",
	"test_dmd.lua",
	"test_gdc.lua",
	"test_ldc.lua",
}
