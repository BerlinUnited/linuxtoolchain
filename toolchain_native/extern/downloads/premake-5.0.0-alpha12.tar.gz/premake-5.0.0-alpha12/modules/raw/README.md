Premake extension to support writing the raw lua tables.

### Usage ###

Simply generate your project using the `raw` action:
```bash
premake5 raw
```
and open the generated workspace.raw file in any text editor.
