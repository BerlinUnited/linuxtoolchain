return {
	"self-test.lua",
	"test_assertions.lua",
	"test_declare.lua",
	"test_helpers.lua",
	"test_runner.lua"
}
