require ("xcode")

return {
	"test_header_footer.lua",
	"test_xcode4_project.lua",
	"test_xcode4_workspace.lua",
	"test_xcode_dependencies.lua",
	"test_xcode_project.lua",
}
